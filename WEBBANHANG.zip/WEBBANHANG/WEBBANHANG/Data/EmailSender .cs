﻿using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;

namespace WEBBANHANG.Data
{
    public class EmailSender : ICustomEmailSender
    {
        private readonly IConfiguration _configuration;
        public EmailSender(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void SendEmailConfirmation(string toEmail, string confirmationLink)
        {
            var senderEmail = _configuration["EmailSettings:SenderEmail"];
            var senderPassword = _configuration["EmailSettings:SenderPassword"];
            if(string.IsNullOrEmpty(senderEmail) || string.IsNullOrEmpty(senderPassword))
            {
                throw new Exception("Thiếu cấu hình email trong appsettings.json");
            }    
            var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(senderEmail, senderPassword),
                EnableSsl = true,
            };
            var mailMessage = new MailMessage
            {
                From = new MailAddress(senderEmail),
                Subject = "Xác thực tài khoản CMS Fabi",
                Body = $@"
                    <div style='font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;border:1px sold #ddd;border-radius:10px;'>
                        <p>Xin chào,</p>
                        <p>Cảm ơn bạn đã đăng ký sử dụng Fabi. Vui lòng nhấp vào nút dưới đây để xác thực tài khoản của bạn.</p>
                        <p style='text-align:center;>
                            <a href='{confirmationLink}' style='display:inline-block;padding: 10px 20px; background-color:#2196F3;color:#fff;text-decoration:none;border-radius:5px;'>Xác thực tài khoản</a>
                        </p>
                        <p style='color:#666;font-size:13px;'>Lưu ý: Yêu cầu xác thực tài khoản chỉ có hiệu lực trong 30 phút. Nếu sau khoản thời gian trên, bạn cần gửi lại yêu cầu để xác thực tài khoản.</p>
                        <p>Cảm ơn!</p>
                    </div>",
                IsBodyHtml = true,
            };
            mailMessage.To.Add(toEmail);
            try
            {
                smtpClient.Send(mailMessage);
            }
            catch (SmtpException smtpEx)
            {
                Console.WriteLine("SMTP lỗi: " + smtpEx.Message);
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi chung khi gửi email: " + ex.Message);
                throw;
            }
        }
    }
}
