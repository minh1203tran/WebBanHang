﻿namespace WEBBANHANG.Data
{
    public interface ICustomEmailSender
    {
        void SendEmailConfirmation(string toEmail, string confirmationLink);
    }
}
