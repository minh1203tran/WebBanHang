﻿using Microsoft.AspNetCore.Mvc;
using WEBBANHANG.Models;
using WEBBANHANG.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.UI.Services;
using System.Data;

namespace WEBBANHANG.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        private readonly ICustomEmailSender _emailSender;
        public AccountController(AppDbContext context, ICustomEmailSender emailSender)
        {  
            _context = context; 
            _emailSender = emailSender;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                //var user = _context.Users.FirstOrDefault(u => u.Email == model.Email && u.Password == model.Password);
                //if (user != null)
                //{
                //    HttpContext.Session.SetInt32("UserId", user.UserId);
                //    var hasBrand = _context.Brands.Any(b => b.UserId == user.UserId);
                //    if(!hasBrand)
                //    {
                //        return RedirectToAction("Choose", "Brand");
                //    }    
                //    return RedirectToAction("Index", "Home");
                //}
                //else
                //{
                //    TempData["LoginError"] = "Tài khoản hoặc mật khẩu không đúng hoặc không tồn tại.";
                //    return RedirectToAction("Login");
                //}
                int userId = 0;
                string userName = "";
                using (var command = _context.Database.GetDbConnection().CreateCommand())
                {
                    command.CommandText = "SP_CHECKLOGIN";
                    command.CommandType = CommandType.StoredProcedure;
                    var paramEmail = command.CreateParameter();
                    paramEmail.ParameterName = "@Email";
                    paramEmail.Value = model.Email;
                    command.Parameters.Add(paramEmail);
                    var paramPassword = command.CreateParameter();
                    paramPassword.ParameterName = "@Password";
                    paramPassword.Value = model.Password;
                    command.Parameters.Add(paramPassword);
                    if (command.Connection.State != ConnectionState.Open)
                        command.Connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userId = reader.GetInt32(reader.GetOrdinal("UserId"));
                            userName = reader.GetString(reader.GetOrdinal("Username"));
                        }
                    }
                }
                if (userId > 0)
                {
                    HttpContext.Session.SetInt32("UserId", userId);
                    HttpContext.Session.SetString("Username", userName);
                    bool hasBrand = _context.Brands.Any(b => b.UserId == userId);
                    if (!hasBrand)
                        return RedirectToAction("Choose", "Brand");
                    return RedirectToAction("Index", "Home");
                }
                TempData["LoginError"] = "Tài khoản hoặc mật khẩu không đúng hoặc không tồn tại.";
                return RedirectToAction("Login");
            }
            return View(model);
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var usernameParem = new SqlParameter("@Username", model.Username);
                    var emailParem = new SqlParameter("@Email", model.Email);
                    var passwordParam = new SqlParameter("@PassWord", model.Password);
                    //var confirmPasswordParam = new SqlParameter("@ConfirmPassword", model.ConfirmPassword);
                    var countryParem = new SqlParameter("@Country", model.Country);
                    _context.Database.ExecuteSqlRaw(
                        "EXEC sp_RegisterUser @Username, @Email, @Password, @Country", usernameParem, emailParem, passwordParam, countryParem
                    );
                    ViewBag.Email = model.Email;
                    return View("ConfirmEmail");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "Đăng ký thất bại: " + ex.Message);
                }
            }
            return View(model);
        }

        public IActionResult ConfirmEmail()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ConfirmEmail(string email)
        {
            if(string.IsNullOrEmpty(email))
            {
                return BadRequest("Email không được để trống");
            }    
            var user = _context.Users.FirstOrDefault(u => u.Email == email);
            if (user == null)
            {
                return NotFound("Không tìm thấy người dùng");
            }
            var confirmationLink = Url.Action("ConfirmEmail", "Account", new {email =  email }, Request.Scheme);
            if(confirmationLink == null)
            {
                _emailSender.SendEmailConfirmation(email, confirmationLink);
            }
            return Ok("Email xác thực đã được gửi lại.");
        }
    }
}
