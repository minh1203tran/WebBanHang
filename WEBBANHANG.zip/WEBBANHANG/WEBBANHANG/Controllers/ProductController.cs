﻿using Microsoft.AspNetCore.Mvc;
using WEBBANHANG.Data;
using WEBBANHANG.Models;
using System.Linq;
using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace WEBBANHANG.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _context;

        public ProductController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Create()
        {
            var brands = _context.Brands.ToList();
            if (!brands.Any())
            {
                ViewBag.ShowBrandFrom = true;
            }
            ViewBag.Brands = brands;
            return View();
        }

        [HttpPost]
        public IActionResult CreateBrand(string brandName)
        {
            if (!string.IsNullOrWhiteSpace(brandName))
            {
                var brand = new Brand { BrandName = brandName };
                _context.Brands.Add(brand);
                _context.SaveChanges();
            }
            return RedirectToAction("Create");
        }

        [HttpPost]
        public IActionResult CreateProduct(string productName, int brandId)
        {
            if (string.IsNullOrWhiteSpace(productName))
            {
                ModelState.AddModelError("productName", "Tên sản phẩm không được để trống.");
                return View();
            }
            var connection = _context.Database.GetDbConnection();
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "InsertBrandAndProduct";
                command.CommandType = CommandType.StoredProcedure;
                var paramBrandId = command.CreateParameter();
                paramBrandId.ParameterName = "@BrandName";
                paramBrandId.Value = brandId;
                command.Parameters.Add(paramBrandId);
                var paramProductName = command.CreateParameter();
                paramProductName.ParameterName = "@ProductName";
                paramProductName.Value = productName;
                command.Parameters.Add(paramProductName);
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                command.ExecuteNonQuery();
            }
            return RedirectToAction("Create");
        }

        [HttpPost]
        public IActionResult CreateBrandAndProduct(string brandName, string productName)
        {
            if (string.IsNullOrWhiteSpace(brandName) || string.IsNullOrWhiteSpace(productName))
            {
                ModelState.AddModelError("", "Tên thương hiệu và sản phầm không được để trống.");
                return RedirectToAction("Create");
            }
            var connection = _context.Database.GetDbConnection();
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "InsertBrandAndProduct";
                command.CommandType = CommandType.StoredProcedure;
                var paramBrand = command.CreateParameter();
                paramBrand.ParameterName = "@BrandName";
                paramBrand.Value = brandName;
                command.Parameters.Add(paramBrand);
                var paramProduct = command.CreateParameter();
                paramProduct.ParameterName = "@ProductName";
                paramProduct.Value = productName;
                command.Parameters.Add(paramProduct);
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                command.ExecuteNonQuery();
            }
            return RedirectToAction("Create");
        }
    }
}
