﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using WEBBANHANG.Data;
using WEBBANHANG.Models;

namespace WEBBANHANG.Controllers
{
    public class BrandController : Controller
    {
        private readonly AppDbContext _context;

        public BrandController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Choose()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }
            var brands = _context.Brands.Where(b => b.UserId == userId).ToList();
            //if (!brands.Any())
            //{
            //    ViewBag.ShowBrandFrom = true;
            //}
            ViewBag.ShowBrandFrom = !brands.Any();
            ViewBag.Brands = brands;
            ViewBag.UserId = userId;
            return View();
        }

        [HttpPost]
        public IActionResult ChooseBrand(string brandName)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
                return RedirectToAction("Login", "Account");
            if (!string.IsNullOrWhiteSpace(brandName))
            {
                var brand = new Brand { BrandName = brandName, UserId = userId.Value };
                _context.Brands.Add(brand);
                _context.SaveChanges();
            }
            return RedirectToAction("Create");
        }

        [HttpPost]
        public IActionResult ChooseProduct(string productName, int brandId)
        {
            if (string.IsNullOrWhiteSpace(productName))
            {
                ModelState.AddModelError("productName", "Tên sản phẩm không được để trống.");
                return View();
            }
            var connection = _context.Database.GetDbConnection();
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "InsertBrandAndProduct";
                command.CommandType = CommandType.StoredProcedure;
                var paramBrandId = command.CreateParameter();
                paramBrandId.ParameterName = "@BrandName";
                paramBrandId.Value = brandId;
                command.Parameters.Add(paramBrandId);
                var paramProductName = command.CreateParameter();
                paramProductName.ParameterName = "@ProductName";
                paramProductName.Value = productName;
                command.Parameters.Add(paramProductName);
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                command.ExecuteNonQuery();
            }
            return RedirectToAction("Create");
        }

        [HttpPost]
        public IActionResult ChooseBrandAndProduct(string brandName, string productName)
        {
            if (string.IsNullOrWhiteSpace(brandName) || string.IsNullOrWhiteSpace(productName))
            {
                ModelState.AddModelError("", "Tên thương hiệu và sản phầm không được để trống.");
                return RedirectToAction("Create");
            }
            var connection = _context.Database.GetDbConnection();
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "InsertBrandAndProduct";
                command.CommandType = CommandType.StoredProcedure;
                var paramBrand = command.CreateParameter();
                paramBrand.ParameterName = "@BrandName";
                paramBrand.Value = brandName;
                command.Parameters.Add(paramBrand);
                var paramProduct = command.CreateParameter();
                paramProduct.ParameterName = "@ProductName";
                paramProduct.Value = productName;
                command.Parameters.Add(paramProduct);
                if (connection.State != ConnectionState.Open)
                    connection.Open();
                command.ExecuteNonQuery();
            }
            return RedirectToAction("Create");
        }
    }
}
