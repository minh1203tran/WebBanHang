﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WEBBANHANG.Models;

namespace WEBBANHANG.Models
{
    public class RegisterModel
    {
        [Required(ErrorMessage = "Vui lòng nhập tên tài khoản.")]
        [Display(Name = "Tên tài khoản")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập email.")]
        [EmailAddress(ErrorMessage = "Email không hợp lệ.")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu.")]
        [DataType(DataType.Password)]
        [Display(Name = "Mật khẩu")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Xác nhận mật khẩu")]
        [Compare("Password", ErrorMessage = "Mật khẩu không khớp.")]
        [NotMapped]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn quốc gia.")]
        [Display(Name = "Quốc gia")]
        public string Country { get; set; } = "Việt Nam";

        [MustBeTrue(ErrorMessage = "Vui lòng đồng ý với điều khoản")]
        [Display(Name = "Tôi đồng ý với quy định chung, chính sách bảo hành và chính sách bảo mật")]
        public bool AgreeToTerms { get; set; }
    }
}
