﻿namespace WEBBANHANG.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int BrandId { get; set; }
        public Brand Brand { get; set; }
    }
}
