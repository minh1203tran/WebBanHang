﻿using System.ComponentModel.DataAnnotations;

namespace WEBBANHANG.Models
{
    public class MustBeTrue : ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            return value is bool b && b;
        }
    }
}
